#include <GL/glut.h>
#include<iostream>
#include<stdlib.h>
#include<stdio.h>
using namespace std;
int cnt=0;
char E[10]={'T','O','P',' ','S','C','O','R','E'};
int score,exit1=0;
int h=score;
float x,y;
float x1,y1=1000,x2=200,x3=-200,y2=1500,y3=2000;
int time=0;
 struct lines
		{
	       int x,y;
		};
		struct lines line[5];

		void createline()
		{
		    int i=0;
			for(;i<5;i++)
			{
				line[i].x=0;
				line[i].y=i*250;
			}
		}
// Enemy car creation!!
void enemy(float a,float b)
{

	glBegin(GL_QUADS);
	glColor3f(1,0,1);
	glVertex2f(-75+a,50+b);
	glVertex2f(-75+a,100+b);
	glVertex2f(75+a,100+b);
	glVertex2f(75+a,50+b);

	glColor3f(1,0,1);
	glVertex2f(-75+a,150+b);
	glVertex2f(-75+a,200+b);
	glVertex2f(75+a,200+b);
	glVertex2f(75+a,150+b);

	glColor3f(0,0,1);
	glVertex2f(-25+a,40+b);
	glVertex2f(-25+a,250+b);
	glVertex2f(25+a,250+b);
	glVertex2f(25+a,40+b);

	glEnd();
}

void sc(int a)
{

        int temp=a;
        int x,y,z;
        int i,j,k;
        i=a%10;
        a=a/10;
        j=a%10;
        a=a/10;
        k=a%10;
	glPushMatrix();

	glColor3f(0.0,0.0,0.0);

	glTranslated(400,800,0);
	glScaled(.5,.5,0);
    glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'S');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'c');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'o');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'r');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'e');
	glColor3f(1.0,0.0,1.0);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)':');
	glColor3f(0.0,0.0,0.0);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)a);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)k+48);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)j+48);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)i+48);
	glPopMatrix();




    glPushMatrix();

	glColor3f(1,1,1);
	glTranslated(-900,900,0);
	glScaled(.5,.5,0);
	char L1[7]={'L','E','V','E','L','-','1'};
	if(temp<25)
    {
        L1[6]='1';
	for(int i=0;i<7;i++)
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)L1[i]);

    }

	glPopMatrix();




    glPushMatrix();

	glColor3f(1,1,1);
	glTranslated(-900,900,0);
	glScaled(.5,.5,0);
//	cout<<temp<<"score hai"<<endl;
	 if(temp>=25 && temp<50)
    {
        L1[6]='2';
	for(int i=0;i<7;i++)
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)L1[i]);
    }
	glPopMatrix();



    glPushMatrix();

	glColor3f(1,1,1);
	glTranslated(-900,900,0);
	glScaled(.5,.5,0);
	if(temp>=50)
    {
        L1[6]='3';
	for(int i=0;i<7;i++)
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)L1[i]);
    }
	glPopMatrix();





	glPushMatrix();
	//int h=max(a,h);
	cnt++;
	int num;
    FILE *fptr;
    fptr=fopen("C://Users//HASSSAN//Desktop//High.txt","r");
    fscanf(fptr,"%d",&num);
    fclose(fptr);
    if(cnt==1)
    {
        FILE *fptr1;
        fptr1=fopen("C://Users//HASSSAN//Desktop//High1.txt","w");
        fprintf(fptr1,"%d",num);
        fclose(fptr1);
    }


   // printf("%d %d\n",num,temp);
 //  int num1=num;
    if(temp>num)
    {
        FILE *f;
        f=fopen("C://Users//HASSSAN//Desktop//High.txt","w");
        fprintf(f,"%d",temp);
        fclose(f);
    }
       int num3;
       FILE *fptr1;
        fptr1=fopen("C://Users//HASSSAN//Desktop//High1.txt","r");
        fscanf(fptr1,"%d",&num3);
        fclose(fptr1);

      // num=min(temp,num);
                x=num3%10;
                num3=num3/10;
                y=num3%10;
                num3=num3/10;
                z=num3%10;



	glColor3f(0.0,0.0,0.0);

	glTranslated(400,700,0);
	glScaled(.3,.3,0);
  	for(int i=0;i<10;i++)
    {
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)E[i]);

    }
	glColor3f(1.0,0.0,1.0);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)':');
	glColor3f(1,1,1);
//	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)a);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)z+48);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)y+48);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)x+48);
	glPopMatrix();




    glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glTranslated(300,50,0);
	glScaled(.3,.3,0);
		char F[22]={'P','R','E','S','S',' ','s',' ','T','O',' ','S','T','A','R','T',' ','G','A','M','E'};
	for(int i=0;i<22;i++)
    {
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)F[i]);

    }
	glPopMatrix();

	glPushMatrix();
	glColor3f(1.0,1.0,1.0);
	glTranslated(400,500,0);
	glScaled(.6,.6,0);
    	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'->');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)' ');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'C');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'A');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'R');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)' ');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'R');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'A');
    glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'C');
    glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'E');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)' ');

	glPopMatrix();



glPushMatrix();
	glColor3f(1.0,1,1.0);
	glTranslated(300,90,0);
	glScaled(.3,.3,0);
			char G[22]={'P','R','E','S','S','  ','q',' ','T','O',' ','Q','U','I','T',' ','G','A','M','E'};
	for(int i=0;i<22;i++)
    {
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)G[i]);

    }
glPopMatrix();

}
//My Car Creation

void car(float a,float b)
{
	glBegin(GL_QUADS);

	glColor3f(0,1,1);
	glVertex2f(-75+a,50+b);
	glVertex2f(-75+a,100+b);
	glVertex2f(75+a,100+b);
	glVertex2f(75+a,50+b);

	glColor3f(0,1,1);
	glVertex2f(-75+a,150+b);
	glVertex2f(-75+a,200+b);
	glVertex2f(75+a,200+b);
	glVertex2f(75+a,150+b);

	glColor3f(1,1,0);
	glVertex2f(-25+a,40+b);
	glVertex2f(-25+a,250+b);
	glVertex2f(25+a,250+b);
	glVertex2f(25+a,40+b);
	glEnd();
}

void display()
{
    int i,t;
	time++;
	if(exit1==0)
	{
		if(score<25)
		{

                y1--;
                y2--;
                y3--;
		}
        if(score>=25&&score<50)
                {
                    y1-=1.5;
                    y2-=1.5;
                    y3-=1.5;
                }
        if(score>=50)
                {
                    y1-=2;
                    y2-=2;
                    y3-=2;
                }

	if(y1<-250)
	{
		score+=5;
	    y1=1000;
	}
	if(y2<-250)
	{
		score+=5;
		y2=1500;
	}
	if(y3<-250)
	{
		score+=5;
		y3=2000;
	}


	if(x<-255||x>255)exit1=1;  //Intersection b/w Boundary
     //Intersection b/w cars!!
	if(75+x>-80&&-75+x<80)         //Middle Enemy collision
	if(250+y>100+y1&&250+y1>40+y)
		exit1=1;

	if(75+x>-260&&-75+x<-140)      //Left Enemy collision
	if(250+y>100+y3&&250+y3>40+y)
		exit1=1;

	if(75+x>140&&-75+x<260)        //Right Enemy Collision
	if(250+y>100+y2&&250+y2>40+y)
		exit1=1;

	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(0,1,0);

    glBegin(GL_QUADS);
	glVertex2f(-300,0);
	glVertex2f(-300,1000);
	glVertex2f(-1000,1000);
	glVertex2f(-1000,0);

	glVertex2f(300,0);
	glVertex2f(300,1000);
	glVertex2f(1000,1000);
	glVertex2f(1000,0);
	glEnd();
    //Divider in the road!!
	glColor3f(0.0,0.0,0.0);  //Black color divider!!
	t=0;
	glPushMatrix();
	for(i=0;i<5;i++)
		{
		    line[i].y+=-2;
		    //<<line[i].y<<endl;
    if(line[i].y<-200)
    {
        line[i].y+=1200;
    }
		}
	for(i=0;i<5;i++)
	{


	    glBegin(GL_POLYGON);
		glVertex2f(line[i].x,line[i].y+40);
		glVertex2f(line[i].x,line[i].y+190);
		glVertex2f(line[i].x+40,line[i].y+190);
		glVertex2f(line[i].x+40,line[i].y+40);
		glEnd();
	}
     glPopMatrix();

    glFlush();

	sc(score);
	//cout<<x<<" "<<y<<endl;
	car(x,y);
	enemy(x1,y1);
	enemy(x2,y2);
	enemy(x3,y3);
	glutSwapBuffers();

	}
    //If exit1=0 Game Over Case
	else
	{
    glLineWidth(5);
	glClear(GL_COLOR_BUFFER_BIT);
	sc(score);


	glPushMatrix();
	glColor3f(0,0,0);
	glTranslated(-200,800,0);
	glScaled(.5,.5,0);
	char D[9]={'G','A','M','E','O','V','E','R'};
	for(int i=0;i<9;i++)
    {
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)D[i]);

    }
	glPopMatrix();
	glPushMatrix();
	//int h=max(a,h);
	int num3;
    FILE *fptr;
    fptr=fopen("C://Users//HASSSAN//Desktop//High.txt","r");
    fscanf(fptr,"%d",&num3);
    fclose(fptr);
   // printf("%d %d\n",num,temp);
       int x1,y1,z1;
        x1=num3%10;
        num3=num3/10;
        y1=num3%10;
        num3=num3/10;
        z1=num3%10;

	glColor3f(0.0,0.0,0.0);

	glTranslated(400,700,0);
	glScaled(.3,.3,0);

	for(int i=0;i<10;i++)
    {
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)E[i]);

    }
	glColor3f(1.0,0.0,1.0);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)':');
	glColor3f(0,0,0);
//	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)a);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)z1+48);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)y1+48);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)x1+48);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslated(-200,500,0);
	glScaled(.5,.5,0);

    glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'B');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)'y');
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslated(-200,400,0);
	glScaled(.5,.5,0);
	char A[13]={'A','R','I','F',' ','H','A','S','S','A','N','!'};
	for(int i=0;i<12;i++)
    {
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)A[i]);

    }
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslated(-200,300,0);
	glScaled(.5,.5,0);
	char B[14]={'A','K','A','S','H',' ','R','A','N','J','A','N','!'};
	for(int i=0;i<14;i++)
    {
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)B[i]);

    }
	glPopMatrix();

	glPushMatrix();
	glColor3f(0,0,0);
	glTranslated(-200,200,0);
	glScaled(.5,.5,0);

	char C[18]={'A','R','K','A','P','R','A','B','H','A',' ','K','H','A','N','!'};
	for(int i=0;i<18;i++)
    {
        glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN,(int)C[i]);

    }
	glPopMatrix();
	glutSwapBuffers();
	}
}
void keyboards(unsigned char keys,int x4,int y4)
{
	//to quit
    if(keys=='q'||keys=='Q')
	{
		  exit(-1);
	}
	//to start
	if(keys=='s' ||keys=='S')
    {
		glutIdleFunc(display);
    }
	glutPostRedisplay();

}
void dropmenu(int keys)
{
	  keyboards((unsigned char) keys,0,0);
}
void SpecialInput(int k, int p, int q)
{
    if (k == GLUT_KEY_LEFT)
        x -=20;
     else if (k == GLUT_KEY_RIGHT)
        x+=20;
    else if (k == GLUT_KEY_UP)
        y +=20;
    else if (k == GLUT_KEY_DOWN)
        y -=20;
     glutPostRedisplay();
}
int main(int argc, char **argv)
{


  glutInit(&argc,argv);// Initialize GLUT
  glutInitWindowSize(1366,740);// Set the window's initial width & height
  glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
  glutCreateWindow("Car Racing Game");
  glClearColor(1,1,1,0.8);//set Background

  glutDisplayFunc(display);// Register display callback handler for window re-paint

  glutSpecialFunc(SpecialInput);
  glutKeyboardFunc(keyboards);
  createline();
  gluOrtho2D(-1000,1000,0,1000);
  glutMainLoop();// Enter the event-processing loop
  return 0;
}
